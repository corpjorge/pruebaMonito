CREATE TABLE Co_Banco 
    ( 
     banco NUMBER  NOT NULL , 
     nombre VARCHAR2 (200 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_Convenio 
    ( 
     convenio NUMBER  NOT NULL , 
     fechaInicio DATE  NOT NULL , 
     FechaFin DATE  NOT NULL , 
     estudiante NUMBER  NOT NULL , 
     tipoCuenta VARCHAR2 (50 CHAR)  NOT NULL , 
     numeroCuenta VARCHAR2 (100 CHAR)  NOT NULL , 
     banco NUMBER  NOT NULL , 
     dependencia NUMBER  NOT NULL , 
     tipoMonitor NUMBER  NOT NULL , 
     tipoLabor NUMBER  NOT NULL , 
     periodoAcademico NUMBER  NOT NULL , 
     valorHora NUMBER  NOT NULL , 
     horasSemanales INTEGER  NOT NULL , 
     descripcionInvestigacion VARCHAR2 (4000 CHAR) , 
     estado INTEGER 
    ) LOGGING 
;




CREATE TABLE Co_Dependencia 
    ( 
     dependencia NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL , 
     facultad NUMBER 
    ) LOGGING 
;




CREATE TABLE Co_DistribucionPresupuestal 
    ( 
     distribucionPresupuestal NUMBER  NOT NULL , 
     fondoPresupuestal VARCHAR2 (100 CHAR)  NOT NULL , 
     Porcentaje NUMBER (8,2)  NOT NULL , 
     objetoCosto VARCHAR2 (200 CHAR)  NOT NULL , 
     convenio NUMBER  NOT NULL , 
     tipoObjeto VARCHAR2 (200 CHAR) 
    ) LOGGING 
;




CREATE TABLE Co_EstadoEstudiante 
    ( 
     estadoEstudiante VARCHAR2 (2 CHAR)  NOT NULL , 
     nombre VARCHAR2 (100 CHAR)  NOT NULL , 
     descripcion VARCHAR2 (1000) 
    ) LOGGING 
;




CREATE TABLE Co_Estudiante 
    ( 
     estudiante NUMBER  NOT NULL , 
     nombres VARCHAR2 (250 CHAR)  NOT NULL , 
     apellidos VARCHAR2 (250 CHAR)  NOT NULL , 
     direccion VARCHAR2 (250 CHAR)  NOT NULL , 
     telefono VARCHAR2 (50 CHAR)  NOT NULL , 
     email VARCHAR2 (100 CHAR)  NOT NULL , 
     genero VARCHAR2 (1 CHAR)  NOT NULL , 
     lugarExpedicionDocumento VARCHAR2 (100 CHAR)  NOT NULL , 
     codigo VARCHAR2 (150 CHAR)  NOT NULL , 
     documento VARCHAR2 (150 CHAR)  NOT NULL , 
     estado VARCHAR2 (2 CHAR) , 
     ciudad NUMBER  NOT NULL , 
     tipoDoc NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_Materia 
    ( 
     materia NUMBER  NOT NULL , 
     curso VARCHAR2 (100 CHAR)  NOT NULL , 
     convenio NUMBER , 
     crn INTEGER  NOT NULL , 
     nombre VARCHAR2 (500 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_Pago 
    ( 
     pago NUMBER  NOT NULL , 
     valor NUMBER  NOT NULL , 
     convenio NUMBER  NOT NULL , 
     porcentajePagos NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_PeriodoAcademico 
    ( 
     periodoAcademico NUMBER  NOT NULL , 
     fechaInicial DATE  NOT NULL , 
     fechaFinal DATE  NOT NULL , 
     fechaInicialReceso DATE  NOT NULL , 
     fechaFinalReceso DATE  NOT NULL , 
     minimoHoras INTEGER  NOT NULL , 
     maximoHoras INTEGER  NOT NULL , 
     periodoSemestre VARCHAR2 (50 CHAR)  NOT NULL , 
     minimoValorHora NUMBER  NOT NULL , 
     maximoValorHora NUMBER  NOT NULL , 
     fechaLimite DATE 
    ) LOGGING 
;




CREATE TABLE Co_PlanPagos 
    ( 
     planPagos NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL , 
     periodoAcademico NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_PorcentajePagos 
    ( 
     porcentajePagos NUMBER  NOT NULL , 
     posicion INTEGER  NOT NULL , 
     porcentaje NUMBER (5,2)  NOT NULL , 
     planPagos NUMBER  NOT NULL , 
     fecha DATE  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_TextoFormatoConvenio 
    ( 
     textoFormatoConvenio NUMBER  NOT NULL , 
     texto VARCHAR2 (4000 CHAR)  NOT NULL , 
     etiqueta VARCHAR2 (50 CHAR)  NOT NULL , 
     periodoAcademico NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_TipoLabor 
    ( 
     tipoLabor NUMBER  NOT NULL , 
     descripcion VARCHAR2 (4000 CHAR)  NOT NULL , 
     labor VARCHAR2 (200 CHAR)  NOT NULL , 
     nombre VARCHAR2 (200 CHAR)  NOT NULL , 
     tipoMonitorDefecto NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Co_TipoMonitor 
    ( 
     tipoMonitor NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL , 
     minimoValorHora NUMBER , 
     maximoValorHora NUMBER 
    ) LOGGING 
;




CREATE TABLE Co_TipoMonitorDependencia 
    ( 
     dependencia NUMBER  NOT NULL , 
     tipoMonitor NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Ciudad 
    ( 
     ciudad NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL , 
     departamento NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Departamento 
    ( 
     depto NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL , 
     pais NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Pagina 
    ( 
     pagina NUMBER  NOT NULL , 
     url VARCHAR2 (4000 CHAR)  NOT NULL , 
     descripcion VARCHAR2 (1000 CHAR) 
    ) LOGGING 
;




CREATE TABLE G_PaginaRol 
    ( 
     rol NUMBER  NOT NULL , 
     pagina NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Pais 
    ( 
     pais NUMBER  NOT NULL , 
     nombre VARCHAR2 (150 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Rol 
    ( 
     rol NUMBER  NOT NULL , 
     nombre VARCHAR2 (200 CHAR)  NOT NULL , 
     descripcion VARCHAR2 (1000 CHAR) 
    ) LOGGING 
;




CREATE TABLE G_TipoDocumento 
    ( 
     tipoDoc NUMBER  NOT NULL , 
     nombre VARCHAR2 (100 CHAR)  NOT NULL , 
     descripcion VARCHAR2 (1000 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE G_Usuario 
    ( 
     usuario NUMBER  NOT NULL , 
     nombreUsuario VARCHAR2 (100)  NOT NULL , 
     contrasena VARCHAR2 (100 CHAR)  NOT NULL , 
     email VARCHAR2 (150 CHAR)  NOT NULL , 
     nombre VARCHAR2 (200) , 
     apellidos VARCHAR2 (200 CHAR)  NOT NULL , 
     direccion VARCHAR2 (250 CHAR)  NOT NULL , 
     rol NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Lo_CuentaCobro 
    ( 
     referencia VARCHAR2 (100 CHAR)  NOT NULL , 
     fecha DATE  NOT NULL , 
     valor NUMBER  NOT NULL , 
     loginAutoriza VARCHAR2 (200 CHAR)  NOT NULL , 
     nombreAutoriza VARCHAR2 (300 CHAR)  NOT NULL , 
     cargoAutoriza VARCHAR2 (150 CHAR)  NOT NULL , 
     inscripcion VARCHAR2 (100 CHAR) 
    ) LOGGING 
;




CREATE TABLE Lo_DistribucionPresupuestal 
    ( 
     distribucion NUMBER  NOT NULL , 
     objetoCosto VARCHAR2 (200 CHAR)  NOT NULL , 
     fondoPresupuestal VARCHAR2 (100 CHAR)  NOT NULL , 
     porcentaje NUMBER  NOT NULL , 
     tipoObjeto VARCHAR2 (200 CHAR)  NOT NULL , 
     referencia VARCHAR2 (100 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Lo_Estudiante 
    ( 
     codigo VARCHAR2 (50 CHAR)  NOT NULL , 
     documento VARCHAR2 (100 CHAR)  NOT NULL , 
     login VARCHAR2 (100 CHAR)  NOT NULL , 
     correo VARCHAR2 (250 CHAR)  NOT NULL , 
     nombres VARCHAR2 (300 CHAR)  NOT NULL , 
     apellidos VARCHAR2 (300 CHAR)  NOT NULL , 
     telefono VARCHAR2 (100 CHAR)  NOT NULL , 
     celular VARCHAR2 (100 CHAR)  NOT NULL , 
     ciudad NUMBER  NOT NULL , 
     tipoDoc NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Lo_Inscripcion 
    ( 
     maxhoras INTEGER  NOT NULL , 
     fecha DATE  NOT NULL , 
     estado VARCHAR2 (100 CHAR)  NOT NULL , 
     horasReales INTEGER  NOT NULL , 
     codigo VARCHAR2 (50 CHAR)  NOT NULL , 
     labor NUMBER  NOT NULL , 
     consecutivo VARCHAR2 (100 CHAR)  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Lo_Labor 
    ( 
     labor NUMBER  NOT NULL , 
     descripcion VARCHAR2 (4000 CHAR)  NOT NULL , 
     nombre VARCHAR2 (500 CHAR)  NOT NULL , 
     fecha DATE  NOT NULL , 
     valorHora NUMBER  NOT NULL , 
     objetoCosto VARCHAR2 (200 CHAR)  NOT NULL , 
     loginAutoriza VARCHAR2 (200 CHAR)  NOT NULL , 
     tipoLabor VARCHAR2 (200 CHAR)  NOT NULL , 
     maxHoras INTEGER  NOT NULL , 
     periodo NUMBER  NOT NULL 
    ) LOGGING 
;




CREATE TABLE Lo_PeriodoAcademico 
    ( 
     periodo NUMBER  NOT NULL , 
     maxHorasEstudiante INTEGER  NOT NULL , 
     periodosemestre VARCHAR2 (100 CHAR)  NOT NULL , 
     fechaIni DATE  NOT NULL , 
     fechaFin DATE  NOT NULL , 
     maxValorHora NUMBER  NOT NULL , 
     minValorHora NUMBER  NOT NULL , 
     estado VARCHAR2 (200 CHAR)  NOT NULL 
    ) LOGGING 
;


-- Oracle SQL Developer Data Modeler Summary Report: 
-- 
-- CREATE TABLE                            29