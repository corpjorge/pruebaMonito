

DROP INDEX BancoConvenioX
;

DROP INDEX ConvenioEstudianteX
;
DROP INDEX PeriodoAcademicoConvenioX
;
DROP INDEX TipoLaborConvenioX
;
DROP INDEX TipoMonitorConvenioX
;
DROP INDEX DependConvenioX
;



DROP INDEX Depend_Depend_FKX
;


DROP INDEX DistribucionConvenioX
;





DROP INDEX EstadoEstudianteX
;
DROP INDEX CiudadEstudianteX
;
DROP INDEX TipoDocEstudianteX
;


DROP INDEX ConvenioMateriaX
;


DROP INDEX PagoConvenioX
;
DROP INDEX PagoPorcentajeX
;




DROP INDEX PlanPagosPeriodoAcademicoX
;


DROP INDEX PorcentajesPlanPagosX
;


DROP INDEX textoFormatoPeriodoX
;


DROP INDEX TipoMonitorTipoLaborX
;


DROP INDEX FK_ASS_23X
;

DROP INDEX FK_ASS_24X
;



DROP INDEX DepartamentoCiudadX
;



DROP INDEX PaisDepartamentoX
;



DROP INDEX FK_ASS_12X
;
DROP INDEX FK_ASS_13X
;






DROP INDEX RolUsuarioX
;


DROP INDEX InscripcionCtaX
;



DROP INDEX DistribucionCtaX 
;


DROP INDEX CiudadEstudianteX
;
DROP INDEX TipoDocEstudianteX
;



DROP INDEX LaborInscripcionX
;

DROP INDEX estudianteInscripX
;



DROP INDEX PeriodoLaborX
;




ALTER TABLE Co_Convenio 
    DROP CONSTRAINT BancoConvenio
;


ALTER TABLE Lo_Estudiante 
    DROP CONSTRAINT CiudadEstudiante
;


ALTER TABLE Co_Estudiante 
    DROP CONSTRAINT CiudadEstudiante
;


ALTER TABLE Co_Convenio 
    DROP CONSTRAINT ConvenioEstudiante
;


ALTER TABLE Co_Materia 
    DROP CONSTRAINT ConvenioMateria
;


ALTER TABLE G_Ciudad 
    DROP CONSTRAINT DepartamentoCiudad
;


ALTER TABLE Co_Convenio 
    DROP CONSTRAINT DependConvenio
;


ALTER TABLE Co_Dependencia 
    DROP CONSTRAINT Depend_Depend_FK
;


ALTER TABLE Co_DistribucionPresupuestal 
    DROP CONSTRAINT DistribucionConvenio
;


ALTER TABLE Lo_DistribucionPresupuestal 
    DROP CONSTRAINT DistribucionCta
;


ALTER TABLE Co_Estudiante 
    DROP CONSTRAINT EstadoEstudiante
;


ALTER TABLE G_PaginaRol 
    DROP CONSTRAINT FK_ASS_12
;


ALTER TABLE G_PaginaRol 
    DROP CONSTRAINT FK_ASS_13
;


ALTER TABLE Co_TipoMonitorDependencia 
    DROP CONSTRAINT FK_ASS_23
;


ALTER TABLE Co_TipoMonitorDependencia 
    DROP CONSTRAINT FK_ASS_24
;


ALTER TABLE Lo_CuentaCobro 
    DROP CONSTRAINT InscripcionCta
;


ALTER TABLE Lo_Inscripcion 
    DROP CONSTRAINT LaborInscripcion
;


ALTER TABLE Co_Pago 
    DROP CONSTRAINT PagoConvenio
;


ALTER TABLE Co_Pago 
    DROP CONSTRAINT PagoPorcentaje
;


ALTER TABLE G_Departamento 
    DROP CONSTRAINT PaisDepartamento
;


ALTER TABLE Co_Convenio 
    DROP CONSTRAINT PeriodoAcademicoConvenio
;


ALTER TABLE Lo_Labor 
    DROP CONSTRAINT PeriodoLabor
;


ALTER TABLE Co_PlanPagos 
    DROP CONSTRAINT PlanPagosPeriodoAcademico
;


ALTER TABLE Co_PorcentajePagos 
    DROP CONSTRAINT PorcentajesPlanPagos
;


ALTER TABLE G_Usuario 
    DROP CONSTRAINT RolUsuario
;


ALTER TABLE Co_Estudiante 
    DROP CONSTRAINT TipoDocEstudiante
;


ALTER TABLE Lo_Estudiante 
    DROP CONSTRAINT TipoDocEstudiante
;



ALTER TABLE Co_Convenio 
    DROP CONSTRAINT TipoLaborConvenio
;


ALTER TABLE Co_Convenio 
    DROP CONSTRAINT TipoMonitorConvenio
;


ALTER TABLE Co_TipoLabor 
    DROP CONSTRAINT TipoMonitorTipoLabor
;


ALTER TABLE Lo_Inscripcion 
    DROP CONSTRAINT estudianteInscrip
;


ALTER TABLE Co_TextoFormatoConvenio 
    DROP CONSTRAINT textoFormatoPeriodo
;
