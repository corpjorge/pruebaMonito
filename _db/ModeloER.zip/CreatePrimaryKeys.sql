
CREATE UNIQUE INDEX "Banco PKX" ON Co_Banco 
    ( 
     banco ASC 
    ) 
;

ALTER TABLE Co_Banco 
    ADD CONSTRAINT "Banco PK" PRIMARY KEY ( banco ) ;



CREATE UNIQUE INDEX "Convenio PKX" ON Co_Convenio 
    ( 
     convenio ASC 
    ) 
;

ALTER TABLE Co_Convenio 
    ADD CONSTRAINT "Convenio PK" PRIMARY KEY ( convenio ) ;


CREATE UNIQUE INDEX "Dependencia PKX" ON Co_Dependencia 
    ( 
     dependencia ASC 
    ) 
;

ALTER TABLE Co_Dependencia 
    ADD CONSTRAINT "Dependencia PK" PRIMARY KEY ( dependencia ) ;


CREATE UNIQUE INDEX "DistribucionPresupuestal PKX" ON Co_DistribucionPresupuestal 
    ( 
     distribucionPresupuestal ASC 
    ) 
;

ALTER TABLE Co_DistribucionPresupuestal 
    ADD CONSTRAINT "DistribucionPresupuestal PK" PRIMARY KEY ( distribucionPresupuestal ) ;


CREATE UNIQUE INDEX "EstadoEstudiante PKX" ON Co_EstadoEstudiante 
    ( 
     estadoEstudiante ASC 
    ) 
;

ALTER TABLE Co_EstadoEstudiante 
    ADD CONSTRAINT "EstadoEstudiante PK" PRIMARY KEY ( estadoEstudiante ) ;


CREATE UNIQUE INDEX "Estudiante PKX" ON Co_Estudiante 
    ( 
     estudiante ASC 
    ) 
;

ALTER TABLE Co_Estudiante 
    ADD CONSTRAINT "Estudiante PK" PRIMARY KEY ( estudiante ) ;


CREATE UNIQUE INDEX "Materia PKX" ON Co_Materia 
    ( 
     materia ASC 
    ) 
;

ALTER TABLE Co_Materia 
    ADD CONSTRAINT "Materia PK" PRIMARY KEY ( materia ) ;


CREATE UNIQUE INDEX Pago_PKX ON Co_Pago 
    ( 
     pago ASC 
    ) 
;

ALTER TABLE Co_Pago 
    ADD CONSTRAINT Pago_PK PRIMARY KEY ( pago ) ;


CREATE UNIQUE INDEX "PeriodoAcademico PKX" ON Co_PeriodoAcademico 
    ( 
     periodoAcademico ASC 
    ) 
;

ALTER TABLE Co_PeriodoAcademico 
    ADD CONSTRAINT "PeriodoAcademico PK" PRIMARY KEY ( periodoAcademico ) ;

CREATE UNIQUE INDEX "PlanPagos PKX" ON Co_PlanPagos 
    ( 
     planPagos ASC 
    ) 
;

ALTER TABLE Co_PlanPagos 
    ADD CONSTRAINT "PlanPagos PK" PRIMARY KEY ( planPagos ) ;


CREATE UNIQUE INDEX PorcentajePagos_PKX ON Co_PorcentajePagos 
    ( 
     porcentajePagos ASC 
    ) 
;

ALTER TABLE Co_PorcentajePagos 
    ADD CONSTRAINT PorcentajePagos_PK PRIMARY KEY ( porcentajePagos ) ;


CREATE UNIQUE INDEX "textoFormatoConvenio PKX" ON Co_TextoFormatoConvenio 
    ( 
     textoFormatoConvenio ASC 
    ) 
;

ALTER TABLE Co_TextoFormatoConvenio 
    ADD CONSTRAINT "textoFormatoConvenio PK" PRIMARY KEY ( textoFormatoConvenio ) ;


CREATE UNIQUE INDEX "TipoLabor PKX" ON Co_TipoLabor 
    ( 
     tipoLabor ASC 
    ) 
;

ALTER TABLE Co_TipoLabor 
    ADD CONSTRAINT "TipoLabor PK" PRIMARY KEY ( tipoLabor ) ;


CREATE UNIQUE INDEX "TipoMonitor PKX" ON Co_TipoMonitor 
    ( 
     tipoMonitor ASC 
    ) 
;

ALTER TABLE Co_TipoMonitor 
    ADD CONSTRAINT "TipoMonitor PK" PRIMARY KEY ( tipoMonitor ) ;


CREATE UNIQUE INDEX TipoMonitorDependencia__IDXX ON Co_TipoMonitorDependencia 
    ( 
     dependencia ASC , 
     tipoMonitor ASC 
    ) 
;

ALTER TABLE Co_TipoMonitorDependencia 
    ADD CONSTRAINT TipoMonitorDependencia__IDX PRIMARY KEY ( dependencia, tipoMonitor ) ;


CREATE UNIQUE INDEX "G_Ciudad PKX" ON G_Ciudad 
    ( 
     ciudad ASC 
    ) 
;

ALTER TABLE G_Ciudad 
    ADD CONSTRAINT "G_Ciudad PK" PRIMARY KEY ( ciudad ) ;


CREATE UNIQUE INDEX "G_Departamento PKX" ON G_Departamento 
    ( 
     depto ASC 
    ) 
;

ALTER TABLE G_Departamento 
    ADD CONSTRAINT "G_Departamento PK" PRIMARY KEY ( depto ) ;


CREATE UNIQUE INDEX "G_Pagina PKX" ON G_Pagina 
    ( 
     pagina ASC 
    ) 
;

ALTER TABLE G_Pagina 
    ADD CONSTRAINT "G_Pagina PK" PRIMARY KEY ( pagina ) ;


CREATE UNIQUE INDEX PaginaRol__IDXX ON G_PaginaRol 
    ( 
     rol ASC , 
     pagina ASC 
    ) 
;

ALTER TABLE G_PaginaRol 
    ADD CONSTRAINT PaginaRol__IDX PRIMARY KEY ( rol, pagina ) ;



CREATE UNIQUE INDEX "G_Pais PKX" ON G_Pais 
    ( 
     pais ASC 
    ) 
;

ALTER TABLE G_Pais 
    ADD CONSTRAINT "G_Pais PK" PRIMARY KEY ( pais ) ;




CREATE UNIQUE INDEX "G_Rol PKX" ON G_Rol 
    ( 
     rol ASC 
    ) 
;

ALTER TABLE G_Rol 
    ADD CONSTRAINT "G_Rol PK" PRIMARY KEY ( rol ) ;



CREATE UNIQUE INDEX "G_TipoDocumento PKX" ON G_TipoDocumento 
    ( 
     tipoDoc ASC 
    ) 
;

ALTER TABLE G_TipoDocumento 
    ADD CONSTRAINT "G_TipoDocumento PK" PRIMARY KEY ( tipoDoc ) ;


CREATE UNIQUE INDEX "G_Usuario PKX" ON G_Usuario 
    ( 
     usuario ASC 
    ) 
;

ALTER TABLE G_Usuario 
    ADD CONSTRAINT "G_Usuario PK" PRIMARY KEY ( usuario ) ;



CREATE UNIQUE INDEX "Lo_CuentaCobro PKX" ON Lo_CuentaCobro 
    ( 
     referencia ASC 
    ) 
;

ALTER TABLE Lo_CuentaCobro 
    ADD CONSTRAINT "Lo_CuentaCobro PK" PRIMARY KEY ( referencia ) ;


CREATE UNIQUE INDEX "Lo_DistribucionPresupuestal PK" ON Lo_DistribucionPresupuestal 
    ( 
     distribucion ASC 
    ) 
;

ALTER TABLE Lo_DistribucionPresupuestal 
    ADD CONSTRAINT "Lo_DistribucionPresupuestal PK" PRIMARY KEY ( distribucion ) ;


CREATE UNIQUE INDEX "Lo_Estudiante PKX" ON Lo_Estudiante 
    ( 
     codigo ASC 
    ) 
;

ALTER TABLE Lo_Estudiante 
    ADD CONSTRAINT "Lo_Estudiante PK" PRIMARY KEY ( codigo ) ;


CREATE UNIQUE INDEX "Lo_Inscripcion PKX" ON Lo_Inscripcion 
    ( 
     consecutivo ASC 
    ) 
;

ALTER TABLE Lo_Inscripcion 
    ADD CONSTRAINT "Lo_Inscripcion PK" PRIMARY KEY ( consecutivo ) ;


CREATE UNIQUE INDEX "Lo_Labor PKX" ON Lo_Labor 
    ( 
     labor ASC 
    ) 
;

ALTER TABLE Lo_Labor 
    ADD CONSTRAINT "Lo_Labor PK" PRIMARY KEY ( labor ) ;


CREATE UNIQUE INDEX "Lo_PeriodoAcademico PKX" ON Lo_PeriodoAcademico 
    ( 
     periodo ASC 
    ) 
;

ALTER TABLE Lo_PeriodoAcademico 
    ADD CONSTRAINT "Lo_PeriodoAcademico PK" PRIMARY KEY ( periodo ) ;

	
	
CREATE SEQUENCE co_banco_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_banco_trg
 BEFORE INSERT ON co_banco FOR EACH ROW
BEGIN
   IF :NEW.banco IS NULL THEN
     SELECT co_banco_seq.NEXTVAL INTO :NEW.banco FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_convenio_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_convenio_trg
 BEFORE INSERT ON co_convenio FOR EACH ROW
BEGIN
   IF :NEW.convenio IS NULL THEN
     SELECT co_convenio_seq.NEXTVAL INTO :NEW.convenio FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_dependencia_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_dependencia_trg
 BEFORE INSERT ON co_dependencia FOR EACH ROW
BEGIN
   IF :NEW.dependencia IS NULL THEN
     SELECT co_dependencia_seq.NEXTVAL INTO :NEW.dependencia FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_distribucionP_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_distribucionP_trg
 BEFORE INSERT ON co_distribucionPresupuestal FOR EACH ROW
BEGIN
   IF :NEW.DistribucionPresupuestal IS NULL THEN
     SELECT co_distribucionP_seq.NEXTVAL INTO :NEW.DistribucionPresupuestal FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_estadoEstudiante_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_estadoEstudiante_trg
 BEFORE INSERT ON co_estadoEstudiante FOR EACH ROW
BEGIN
   IF :NEW.EstadoEstudiante IS NULL THEN
     SELECT co_estadoEstudiante_seq.NEXTVAL INTO :NEW.EstadoEstudiante FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_estudiante_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_estudiante_trg
 BEFORE INSERT ON co_estudiante FOR EACH ROW
BEGIN
   IF :NEW.Estudiante IS NULL THEN
     SELECT co_estudiante_seq.NEXTVAL INTO :NEW.Estudiante FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_materia_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_materia_trg
 BEFORE INSERT ON co_materia FOR EACH ROW
BEGIN
   IF :NEW.materia IS NULL THEN
     SELECT co_materia_seq.NEXTVAL INTO :NEW.materia FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_pago_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_pago_trg
 BEFORE INSERT ON co_pago FOR EACH ROW
BEGIN
   IF :NEW.pago IS NULL THEN
     SELECT co_pago_seq.NEXTVAL INTO :NEW.pago FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_periodoAcademico_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_periodoAcademico_trg
 BEFORE INSERT ON co_periodoAcademico FOR EACH ROW
BEGIN
   IF :NEW.periodoAcademico IS NULL THEN
     SELECT co_periodoAcademico_seq.NEXTVAL INTO :NEW.periodoAcademico FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_planPagos_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_planPagos_trg
 BEFORE INSERT ON co_planPagos FOR EACH ROW
BEGIN
   IF :NEW.planPagos IS NULL THEN
     SELECT co_planPagos_seq.NEXTVAL INTO :NEW.planPagos FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_porcentajePagos_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_porcentajePagos_trg
 BEFORE INSERT ON co_porcentajePagos FOR EACH ROW
BEGIN
   IF :NEW.porcentajePagos IS NULL THEN
     SELECT co_porcentajePagos_seq.NEXTVAL INTO :NEW.porcentajePagos FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_TextoFormatoConvenio_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_TextoFormatoConvenio_trg
 BEFORE INSERT ON co_TextoFormatoConvenio FOR EACH ROW
BEGIN
   IF :NEW.TextoFormatoConvenio IS NULL THEN
     SELECT co_TextoFormatoConvenio_seq.NEXTVAL INTO :NEW.TextoFormatoConvenio FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_TipoLabor_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_TipoLabor_trg
 BEFORE INSERT ON co_TipoLabor FOR EACH ROW
BEGIN
   IF :NEW.TipoLabor IS NULL THEN
     SELECT co_TipoLabor_seq.NEXTVAL INTO :NEW.TipoLabor FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE co_TipoMonitor_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER co_TipoMonitor_trg
 BEFORE INSERT ON co_TipoMonitor FOR EACH ROW
BEGIN
   IF :NEW.TipoMonitor IS NULL THEN
     SELECT co_TipoMonitor_seq.NEXTVAL INTO :NEW.TipoMonitor FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_Usuario_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_Usuario_trg
 BEFORE INSERT ON g_Usuario FOR EACH ROW
BEGIN
   IF :NEW.Usuario IS NULL THEN
     SELECT g_Usuario_seq.NEXTVAL INTO :NEW.Usuario FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_rol_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_rol_trg
 BEFORE INSERT ON g_rol FOR EACH ROW
BEGIN
   IF :NEW.rol IS NULL THEN
     SELECT g_rol_seq.NEXTVAL INTO :NEW.rol FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_pagina_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_pagina_trg
 BEFORE INSERT ON g_pagina FOR EACH ROW
BEGIN
   IF :NEW.pagina IS NULL THEN
     SELECT g_pagina_seq.NEXTVAL INTO :NEW.pagina FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_pais_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_pais_trg
 BEFORE INSERT ON g_pais FOR EACH ROW
BEGIN
   IF :NEW.pais IS NULL THEN
     SELECT g_pais_seq.NEXTVAL INTO :NEW.pais FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_departamento_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_departamento_trg
 BEFORE INSERT ON g_departamento FOR EACH ROW
BEGIN
   IF :NEW.depto IS NULL THEN
     SELECT g_departamento_seq.NEXTVAL INTO :NEW.depto FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_ciudad_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_ciudad_trg
 BEFORE INSERT ON g_ciudad FOR EACH ROW
BEGIN
   IF :NEW.ciudad IS NULL THEN
     SELECT g_ciudad_seq.NEXTVAL INTO :NEW.ciudad FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE g_TipoDocumento_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER g_TipoDocumento_trg
 BEFORE INSERT ON g_TipoDocumento FOR EACH ROW
BEGIN
   IF :NEW.TipoDoc IS NULL THEN
     SELECT g_TipoDocumento_seq.NEXTVAL INTO :NEW.TipoDoc FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_estudiante_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_estudiante_trg
 BEFORE INSERT ON lo_estudiante FOR EACH ROW
BEGIN
   IF :NEW.codigo IS NULL THEN
     SELECT lo_estudiante_seq.NEXTVAL INTO :NEW.codigo FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_cuentacobro_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_cuentacobro_trg
 BEFORE INSERT ON lo_cuentacobro FOR EACH ROW
BEGIN
   IF :NEW.referencia IS NULL THEN
     SELECT lo_cuentacobro_seq.NEXTVAL INTO :NEW.referencia FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_inscripcion_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_inscripcion_trg
 BEFORE INSERT ON lo_inscripcion FOR EACH ROW
BEGIN
   IF :NEW.consecutivo IS NULL THEN
     SELECT lo_inscripcion_seq.NEXTVAL INTO :NEW.consecutivo FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_labor_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_labor_trg
 BEFORE INSERT ON lo_labor FOR EACH ROW
BEGIN
   IF :NEW.labor IS NULL THEN
     SELECT lo_labor_seq.NEXTVAL INTO :NEW.labor FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_periodoAcademico_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_periodoAcademico_trg
 BEFORE INSERT ON lo_periodoAcademico FOR EACH ROW
BEGIN
   IF :NEW.periodo IS NULL THEN
     SELECT lo_periodoAcademico_seq.NEXTVAL INTO :NEW.periodo FROM DUAL;
   END IF;
END;
/

CREATE SEQUENCE lo_distriP_seq START WITH 100 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER lo_distriP_trg
 BEFORE INSERT ON lo_distriPresupuestal FOR EACH ROW
BEGIN
   IF :NEW.distribucion IS NULL THEN
     SELECT lo_distriP_seq.NEXTVAL INTO :NEW.distribucion FROM DUAL;
   END IF;
END;
/