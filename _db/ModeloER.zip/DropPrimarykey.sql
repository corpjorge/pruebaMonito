DROP INDEX "Banco PKX";

ALTER TABLE Co_Banco 
    DROP CONSTRAINT "Banco PK";



DROP INDEX "Convenio PKX";

ALTER TABLE Co_Convenio 
    DROP CONSTRAINT "Convenio PK";


DROP INDEX "Dependencia PKX";

ALTER TABLE Co_Dependencia 
    DROP CONSTRAINT "Dependencia PK";


DROP INDEX "DistribucionPresupuestal PKX";

ALTER TABLE Co_DistribucionPresupuestal 
    DROP CONSTRAINT "DistribucionPresupuestal PK";


DROP INDEX "EstadoEstudiante PKX"
;

ALTER TABLE Co_EstadoEstudiante 
    DROP CONSTRAINT "EstadoEstudiante PK";


DROP INDEX "Estudiante PKX"
;

ALTER TABLE Co_Estudiante 
    DROP CONSTRAINT "Estudiante PK";


DROP INDEX "Materia PKX"
;

ALTER TABLE Co_Materia 
    DROP CONSTRAINT "Materia PK";


DROP INDEX Pago_PKX
;

ALTER TABLE Co_Pago 
    DROP CONSTRAINT Pago_PK;


DROP INDEX "PeriodoAcademico PKX"
;

ALTER TABLE Co_PeriodoAcademico 
    DROP CONSTRAINT "PeriodoAcademico PK";

DROP INDEX "PlanPagos PKX" ON Co_PlanPagos 
    ( 
     planPagos ASC 
    ) 
;

ALTER TABLE Co_PlanPagos 
    DROP CONSTRAINT "PlanPagos PK";


DROP INDEX PorcentajePagos_PKX
;

ALTER TABLE Co_PorcentajePagos 
    DROP CONSTRAINT PorcentajePagos_PK;


DROP INDEX "textoFormatoConvenio PKX"
;

ALTER TABLE Co_TextoFormatoConvenio 
    DROP CONSTRAINT "textoFormatoConvenio PK";


DROP INDEX "TipoLabor PKX"
;

ALTER TABLE Co_TipoLabor 
    DROP CONSTRAINT "TipoLabor PK";


DROP INDEX "TipoMonitor PKX"
;

ALTER TABLE Co_TipoMonitor 
    DROP CONSTRAINT "TipoMonitor PK";


DROP INDEX TipoMonitorDependencia__IDXX
;

ALTER TABLE Co_TipoMonitorDependencia 
    DROP CONSTRAINT TipoMonitorDependencia__IDX;


DROP INDEX "G_Ciudad PKX"
;

ALTER TABLE G_Ciudad 
    DROP CONSTRAINT "G_Ciudad PK";


DROP INDEX "G_Departamento PKX"
;

ALTER TABLE G_Departamento 
    DROP CONSTRAINT "G_Departamento PK";


DROP INDEX "G_Pagina PKX"
;

ALTER TABLE G_Pagina 
    DROP CONSTRAINT "G_Pagina PK";


DROP INDEX PaginaRol__IDXX
;

ALTER TABLE G_PaginaRol 
    DROP CONSTRAINT PaginaRol__IDX;



DROP INDEX "G_Pais PKX"
;

ALTER TABLE G_Pais 
    DROP CONSTRAINT "G_Pais PK";




DROP INDEX "G_Rol PKX"
;

ALTER TABLE G_Rol 
    DROP CONSTRAINT "G_Rol PK";



DROP INDEX "G_TipoDocumento PKX"
;

ALTER TABLE G_TipoDocumento 
    DROP CONSTRAINT "G_TipoDocumento PK";


DROP INDEX "G_Usuario PKX"
;

ALTER TABLE G_Usuario 
    DROP CONSTRAINT "G_Usuario PK";



DROP INDEX "Lo_CuentaCobro PKX"
;

ALTER TABLE Lo_CuentaCobro 
    DROP CONSTRAINT "Lo_CuentaCobro PK";


DROP INDEX "Lo_DistribucionPresupuestal PK"
;

ALTER TABLE Lo_DistribucionPresupuestal 
    DROP CONSTRAINT "Lo_DistribucionPresupuestal PK";


DROP INDEX "Lo_Estudiante PKX"
;

ALTER TABLE Lo_Estudiante 
    DROP CONSTRAINT "Lo_Estudiante PK";


DROP INDEX "Lo_Inscripcion PKX"
;

ALTER TABLE Lo_Inscripcion 
    DROP CONSTRAINT "Lo_Inscripcion PK";


DROP INDEX "Lo_Labor PKX"
;

ALTER TABLE Lo_Labor 
    DROP CONSTRAINT "Lo_Labor PK";


DROP INDEX "Lo_PeriodoAcademico PKX"
;

ALTER TABLE Lo_PeriodoAcademico 
    DROP CONSTRAINT "Lo_PeriodoAcademico PK";

	
	
DROP SEQUENCE co_banco_seq ;

DROP TRIGGER co_banco_trg;


DROP SEQUENCE co_convenio_seq ;

DROP TRIGGER co_convenio_trg;


DROP SEQUENCE co_dependencia_seq ;

DROP TRIGGER co_dependencia_trg;


DROP SEQUENCE co_distribucionP_seq ;

DROP TRIGGER co_distribucionP_trg;


DROP SEQUENCE co_estadoEstudiante_seq ;

DROP TRIGGER co_estadoEstudiante_trg;


DROP SEQUENCE co_estudiante_seq ;

DROP TRIGGER co_estudiante_trg;


DROP SEQUENCE co_materia_seq ;

DROP TRIGGER co_materia_trg;


DROP SEQUENCE co_pago_seq ;

DROP TRIGGER co_pago_trg;


DROP SEQUENCE co_periodoAcademico_seq ;

DROP TRIGGER co_periodoAcademico_trg;


DROP SEQUENCE co_planPagos_seq ;

DROP TRIGGER co_planPagos_trg;


DROP SEQUENCE co_porcentajePagos_seq ;

DROP TRIGGER co_porcentajePagos_trg;


DROP SEQUENCE co_TextoFormatoConvenio_seq ;

DROP TRIGGER co_TextoFormatoConvenio_trg;


DROP SEQUENCE co_TipoLabor_seq ;

DROP TRIGGER co_TipoLabor_trg;


DROP SEQUENCE co_TipoMonitor_seq ;

DROP TRIGGER co_TipoMonitor_trg;


DROP SEQUENCE g_Usuario_seq ;

DROP TRIGGER g_Usuario_trg;


DROP SEQUENCE g_rol_seq ;

DROP TRIGGER g_rol_trg;


DROP SEQUENCE g_pagina_seq ;

DROP TRIGGER g_pagina_trg;


DROP SEQUENCE g_pais_seq ;

DROP TRIGGER g_pais_trg;


DROP SEQUENCE g_departamento_seq ;

DROP TRIGGER g_departamento_trg;


DROP SEQUENCE g_ciudad_seq ;

DROP TRIGGER g_ciudad_trg;


DROP SEQUENCE g_TipoDocumento_seq ;

DROP TRIGGER g_TipoDocumento_trg;


DROP SEQUENCE lo_estudiante_seq ;

DROP TRIGGER lo_estudiante_trg;


DROP SEQUENCE lo_cuentacobro_seq ;

DROP TRIGGER lo_cuentacobro_trg;


DROP SEQUENCE lo_inscripcion_seq ;

DROP TRIGGER lo_inscripcion_trg;


DROP SEQUENCE lo_labor_seq ;

DROP TRIGGER lo_labor_trg;


DROP SEQUENCE lo_periodoAcademico_seq ;

DROP TRIGGER lo_periodoAcademico_trg;


DROP SEQUENCE lo_distriP_seq ;

DROP TRIGGER lo_distriP_trg;
