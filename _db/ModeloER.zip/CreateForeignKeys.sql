

CREATE INDEX BancoConvenioX ON Co_Convenio 
    ( 
     banco ASC 
    ) 
;
CREATE INDEX ConvenioEstudianteX ON Co_Convenio 
    ( 
     estudiante ASC 
    ) 
;
CREATE INDEX PeriodoAcademicoConvenioX ON Co_Convenio 
    ( 
     periodoAcademico ASC 
    ) 
;
CREATE INDEX TipoLaborConvenioX ON Co_Convenio 
    ( 
     tipoLabor ASC 
    ) 
;
CREATE INDEX TipoMonitorConvenioX ON Co_Convenio 
    ( 
     tipoMonitor ASC 
    ) 
;
CREATE INDEX DependConvenioX ON Co_Convenio 
    ( 
     dependencia ASC 
    ) 
;



CREATE INDEX Depend_Depend_FKX ON Co_Dependencia 
    ( 
     facultad ASC 
    ) 
;


CREATE INDEX DistribucionConvenioX ON Co_DistribucionPresupuestal 
    ( 
     convenio ASC 
    ) 
;





CREATE INDEX EstadoEstudianteX ON Co_Estudiante 
    ( 
     estado ASC 
    ) 
;
CREATE INDEX CiudadEstudianteX ON Co_Estudiante 
    ( 
     ciudad ASC 
    ) 
;
CREATE INDEX TipoDocEstudianteX ON Co_Estudiante 
    ( 
     tipoDoc ASC 
    ) 
;


CREATE INDEX ConvenioMateriaX ON Co_Materia 
    ( 
     convenio ASC 
    ) 
;


CREATE INDEX PagoConvenioX ON Co_Pago 
    ( 
     convenio ASC 
    ) 
;
CREATE INDEX PagoPorcentajeX ON Co_Pago 
    ( 
     porcentajePagos ASC 
    ) 
;




CREATE INDEX PlanPagosPeriodoAcademicoX ON Co_PlanPagos 
    ( 
     periodoAcademico ASC 
    ) 
;


CREATE INDEX PorcentajesPlanPagosX ON Co_PorcentajePagos 
    ( 
     planPagos ASC 
    ) 
;


CREATE INDEX textoFormatoPeriodoX ON Co_TextoFormatoConvenio 
    ( 
     periodoAcademico ASC 
    ) 
;


CREATE INDEX TipoMonitorTipoLaborX ON Co_TipoLabor 
    ( 
     tipoMonitorDefecto ASC 
    ) 
;


CREATE INDEX FK_ASS_23X ON Co_TipoMonitorDependencia 
    ( 
     dependencia ASC 
    ) 
;
CREATE INDEX FK_ASS_24X ON Co_TipoMonitorDependencia 
    ( 
     tipoMonitor ASC 
    ) 
;



CREATE INDEX DepartamentoCiudadX ON G_Ciudad 
    ( 
     departamento ASC 
    ) 
;



CREATE INDEX PaisDepartamentoX ON G_Departamento 
    ( 
     pais ASC 
    ) 
;



CREATE INDEX FK_ASS_12X ON G_PaginaRol 
    ( 
     rol ASC 
    ) 
;
CREATE INDEX FK_ASS_13X ON G_PaginaRol 
    ( 
     pagina ASC 
    ) 
;






CREATE INDEX RolUsuarioX ON G_Usuario 
    ( 
     rol ASC 
    ) 
;


CREATE INDEX InscripcionCtaX ON Lo_CuentaCobro 
    ( 
     inscripcion ASC 
    ) 
;



CREATE INDEX DistribucionCtaX ON Lo_DistribucionPresupuestal 
    ( 
     referencia ASC 
    ) 
;


CREATE INDEX CiudadEstudianteX ON Lo_Estudiante 
    ( 
     ciudad ASC 
    ) 
;
CREATE INDEX TipoDocEstudianteX ON Lo_Estudiante 
    ( 
     tipoDoc ASC 
    ) 
;



CREATE INDEX LaborInscripcionX ON Lo_Inscripcion 
    ( 
     labor ASC 
    ) 
;
CREATE INDEX estudianteInscripX ON Lo_Inscripcion 
    ( 
     codigo ASC 
    ) 
;



CREATE INDEX PeriodoLaborX ON Lo_Labor 
    ( 
     periodo ASC 
    ) 
;




ALTER TABLE Co_Convenio 
    ADD CONSTRAINT BancoConvenio FOREIGN KEY 
    ( 
     banco
    ) 
    REFERENCES Co_Banco 
    ( 
     banco
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_Estudiante 
    ADD CONSTRAINT CiudadEstudiante FOREIGN KEY 
    ( 
     ciudad
    ) 
    REFERENCES G_Ciudad 
    ( 
     ciudad
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Estudiante 
    ADD CONSTRAINT CiudadEstudiante FOREIGN KEY 
    ( 
     ciudad
    ) 
    REFERENCES G_Ciudad 
    ( 
     ciudad
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Convenio 
    ADD CONSTRAINT ConvenioEstudiante FOREIGN KEY 
    ( 
     estudiante
    ) 
    REFERENCES Co_Estudiante 
    ( 
     estudiante
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Materia 
    ADD CONSTRAINT ConvenioMateria FOREIGN KEY 
    ( 
     convenio
    ) 
    REFERENCES Co_Convenio 
    ( 
     convenio
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;


ALTER TABLE G_Ciudad 
    ADD CONSTRAINT DepartamentoCiudad FOREIGN KEY 
    ( 
     departamento
    ) 
    REFERENCES G_Departamento 
    ( 
     depto
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Convenio 
    ADD CONSTRAINT DependConvenio FOREIGN KEY 
    ( 
     dependencia
    ) 
    REFERENCES Co_Dependencia 
    ( 
     dependencia
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Dependencia 
    ADD CONSTRAINT Depend_Depend_FK FOREIGN KEY 
    ( 
     facultad
    ) 
    REFERENCES Co_Dependencia 
    ( 
     dependencia
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_DistribucionPresupuestal 
    ADD CONSTRAINT DistribucionConvenio FOREIGN KEY 
    ( 
     convenio
    ) 
    REFERENCES Co_Convenio 
    ( 
     convenio
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_DistribucionPresupuestal 
    ADD CONSTRAINT DistribucionCta FOREIGN KEY 
    ( 
     referencia
    ) 
    REFERENCES Lo_CuentaCobro 
    ( 
     referencia
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Estudiante 
    ADD CONSTRAINT EstadoEstudiante FOREIGN KEY 
    ( 
     estado
    ) 
    REFERENCES Co_EstadoEstudiante 
    ( 
     estadoEstudiante
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;


ALTER TABLE G_PaginaRol 
    ADD CONSTRAINT FK_ASS_12 FOREIGN KEY 
    ( 
     rol
    ) 
    REFERENCES G_Rol 
    ( 
     rol
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;


ALTER TABLE G_PaginaRol 
    ADD CONSTRAINT FK_ASS_13 FOREIGN KEY 
    ( 
     pagina
    ) 
    REFERENCES G_Pagina 
    ( 
     pagina
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;


ALTER TABLE Co_TipoMonitorDependencia 
    ADD CONSTRAINT FK_ASS_23 FOREIGN KEY 
    ( 
     dependencia
    ) 
    REFERENCES Co_Dependencia 
    ( 
     dependencia
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;


ALTER TABLE Co_TipoMonitorDependencia 
    ADD CONSTRAINT FK_ASS_24 FOREIGN KEY 
    ( 
     tipoMonitor
    ) 
    REFERENCES Co_TipoMonitor 
    ( 
     tipoMonitor
    ) 
    ON DELETE CASCADE 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_CuentaCobro 
    ADD CONSTRAINT InscripcionCta FOREIGN KEY 
    ( 
     inscripcion
    ) 
    REFERENCES Lo_Inscripcion 
    ( 
     consecutivo
    ) 
    ON DELETE SET NULL 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_Inscripcion 
    ADD CONSTRAINT LaborInscripcion FOREIGN KEY 
    ( 
     labor
    ) 
    REFERENCES Lo_Labor 
    ( 
     labor
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Pago 
    ADD CONSTRAINT PagoConvenio FOREIGN KEY 
    ( 
     convenio
    ) 
    REFERENCES Co_Convenio 
    ( 
     convenio
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Pago 
    ADD CONSTRAINT PagoPorcentaje FOREIGN KEY 
    ( 
     porcentajePagos
    ) 
    REFERENCES Co_PorcentajePagos 
    ( 
     porcentajePagos
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE G_Departamento 
    ADD CONSTRAINT PaisDepartamento FOREIGN KEY 
    ( 
     pais
    ) 
    REFERENCES G_Pais 
    ( 
     pais
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Convenio 
    ADD CONSTRAINT PeriodoAcademicoConvenio FOREIGN KEY 
    ( 
     periodoAcademico
    ) 
    REFERENCES Co_PeriodoAcademico 
    ( 
     periodoAcademico
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_Labor 
    ADD CONSTRAINT PeriodoLabor FOREIGN KEY 
    ( 
     periodo
    ) 
    REFERENCES Lo_PeriodoAcademico 
    ( 
     periodo
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_PlanPagos 
    ADD CONSTRAINT PlanPagosPeriodoAcademico FOREIGN KEY 
    ( 
     periodoAcademico
    ) 
    REFERENCES Co_PeriodoAcademico 
    ( 
     periodoAcademico
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_PorcentajePagos 
    ADD CONSTRAINT PorcentajesPlanPagos FOREIGN KEY 
    ( 
     planPagos
    ) 
    REFERENCES Co_PlanPagos 
    ( 
     planPagos
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE G_Usuario 
    ADD CONSTRAINT RolUsuario FOREIGN KEY 
    ( 
     rol
    ) 
    REFERENCES G_Rol 
    ( 
     rol
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Estudiante 
    ADD CONSTRAINT TipoDocEstudiante FOREIGN KEY 
    ( 
     tipoDoc
    ) 
    REFERENCES G_TipoDocumento 
    ( 
     tipoDoc
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_Estudiante 
    ADD CONSTRAINT TipoDocEstudiante FOREIGN KEY 
    ( 
     tipoDoc
    ) 
    REFERENCES G_TipoDocumento 
    ( 
     tipoDoc
    ) 
    NOT DEFERRABLE 
;



ALTER TABLE Co_Convenio 
    ADD CONSTRAINT TipoLaborConvenio FOREIGN KEY 
    ( 
     tipoLabor
    ) 
    REFERENCES Co_TipoLabor 
    ( 
     tipoLabor
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_Convenio 
    ADD CONSTRAINT TipoMonitorConvenio FOREIGN KEY 
    ( 
     tipoMonitor
    ) 
    REFERENCES Co_TipoMonitor 
    ( 
     tipoMonitor
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_TipoLabor 
    ADD CONSTRAINT TipoMonitorTipoLabor FOREIGN KEY 
    ( 
     tipoMonitorDefecto
    ) 
    REFERENCES Co_TipoMonitor 
    ( 
     tipoMonitor
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Lo_Inscripcion 
    ADD CONSTRAINT estudianteInscrip FOREIGN KEY 
    ( 
     codigo
    ) 
    REFERENCES Lo_Estudiante 
    ( 
     codigo
    ) 
    NOT DEFERRABLE 
;


ALTER TABLE Co_TextoFormatoConvenio 
    ADD CONSTRAINT textoFormatoPeriodo FOREIGN KEY 
    ( 
     periodoAcademico
    ) 
    REFERENCES Co_PeriodoAcademico 
    ( 
     periodoAcademico
    ) 
    NOT DEFERRABLE 
;
